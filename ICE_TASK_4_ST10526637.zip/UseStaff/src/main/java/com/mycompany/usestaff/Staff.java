package com.mycompany.usestaff;

/*
 * PROG6112 - Question 2
 * Abstract Staff class - stores the staff number and location, and
 * implements the iStaff interface. printStaffHiring() is left abstract
 * so that subclasses decide how the hiring report is displayed.
 */
public abstract class Staff implements iStaff {

    // Variables to store staff number and location
    private int staffNumber;
    private String staffLocation;

    // Constructor accepts staff number and staff location as parameters
    public Staff(int staffNumber, String staffLocation) {
        this.staffNumber = staffNumber;
        this.staffLocation = staffLocation;
    }

    // Get method - staff number
    @Override
    public int getStaffNumber() {
        return staffNumber;
    }

    // Get method - staff location
    @Override
    public String getStaffLocation() {
        return staffLocation;
    }

    // Get method - determines whether the hiring process must start.
    // Hiring must occur if the staff members are less than 20.
    @Override
    public String getStaffHiringProcess() {
        return (staffNumber < 20) ? "YES" : "NO";
    }

    // Abstract method - each subclass defines how it prints the report
    public abstract void printStaffHiring();
}
