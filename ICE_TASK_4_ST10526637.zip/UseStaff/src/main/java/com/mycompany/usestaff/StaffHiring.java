package com.mycompany.usestaff;

public class StaffHiring extends Staff {

    // Constructor accepts the number of staff members and staff location
    public StaffHiring(int staffNumber, String staffLocation) {
        super(staffNumber, staffLocation);
    }

    // Prints the staff number, location, and whether hiring must occur
    @Override
    public void printStaffHiring() {
        System.out.println();
        System.out.println("STAFF HIRING REPORT");
        System.out.println("********************");
        System.out.println("LOCATION: " + getStaffLocation());
        System.out.println("STAFF NUMBER: " + getStaffNumber());
        System.out.println("HIRE STAFF: " + getStaffHiringProcess());
    }
}
