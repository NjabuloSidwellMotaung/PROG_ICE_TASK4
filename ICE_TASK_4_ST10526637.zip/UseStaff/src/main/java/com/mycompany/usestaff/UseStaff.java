/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.usestaff;

/**
 *
 * @author Njabulo
 */

import java.util.Scanner; // needed to capture user input from the console

// Driver class: this is the one with main(), used to run the program

public class UseStaff {

    public static void main(String[] args) {
         Scanner input = new Scanner(System.in); // creates a Scanner object to read console input

        // Prompt user for the current staff number
        System.out.print("Enter the current staff number: ");
        int staffNumber = input.nextInt(); // reads the integer typed by the user

        input.nextLine(); // clears the leftover newline character from the buffer

        // Prompt user for the staff hiring location
        System.out.print("Enter the staff hiring location: ");
        String staffLocation = input.nextLine(); // reads the full line of text typed by the user

        System.out.println(); // blank line for spacing, matches the sample output

        // Create a StaffHiring object using the values entered by the user
        StaffHiring hiring = new StaffHiring(staffNumber, staffLocation);

        // Call the method that prints the full report
        hiring.printStaffHiring();

        input.close(); // closes the Scanner to free up resources
        
    }
}
